create procedure select_recommond_goods_by_categoryid(IN category_id_param varchar(50))
  BEGIN
  set @order_num=0;set @category='';
select a.*,b.rownum,g.goods_name,c.category_name,c.sort csort,p.category_id parent_category_id,p.category_name parent_category_name,p.subTitle parent_subtitle from sku_tb a 
inner join (
    SELECT sku_id, sku_name, category_id,sort,isDefault,
   case when @category = category_id 
   then @order_num:=@order_num+1 
  else @order_num:=1 end rownum, @category:=category_id FROM sku_tb 
	where category_id in (
	select category_id from category_tb where parent_category_id
	in (
	select category_id from category_tb where parent_category_id = category_id_param) and isDefault = 1)
order by category_id,sort) b 
on a.sku_id=b.sku_id and a.category_id=b.category_id 

left JOIN goods_tb g on a.goods_id = g.goods_id

LEFT JOIN category_tb c on a.category_id = c.category_id

LEFT JOIN category_tb p ON c.parent_category_id = p.category_id
where b.rownum <= 6;
 END;

