create procedure test(IN category_id_param varchar(100))
  BEGIN

select * from category_tb where category_id = category_id_param;

END;

